<?php
/**
 * File name: CategoryDataTable.php
 * Last modified: 2020.04.30 at 08:21:08
 * Author: SmarterVision - https://codecanyon.net/user/smartervision
 * Copyright (c) 2020
 *
 */

namespace App\DataTables;

use App\Models\Category;
use App\Models\User;
use App\subCategory;
use App\Models\CustomField;
use Yajra\DataTables\Services\DataTable;
use Yajra\DataTables\EloquentDataTable;
use Barryvdh\DomPDF\Facade as PDF;

class SubCaVendorDataTable extends DataTable
{
    /**
     * custom fields columns
     * @var array
     */

    /**
     * Build DataTable class.
     *
     * @param mixed $query Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        $dataTable = new EloquentDataTable($query);

        $columns = array_column($this->getColumns(), 'data');
        return $dataTable
            ->editColumn('updated_at', function ($user) {
                return getDateColumn($user, 'updated_at');
            })

            ->editColumn('email', function ($user) {
                return getEmailColumn($user, 'email');
            })
            ->editColumn('status_type', function ($user) {
                return getUserStatus($user);
            })
            ->addColumn('action', 'settings.vendors.datatables_actions')
            ->rawColumns(array_merge($columns, ['action']));
    }

    /**
     * Get columns.
     *
     * @return array
     */
//    protected function getColumns()
//    {
//        $columns = [
//            [
//                'data' => 'name',
//                'title' => trans('lang.category_name'),
//
//            ],
//            [
//                    'data' => 'Parent Category',
//                    'title' => 'Parent Category',
//                    'searchable' => false, 'orderable' => false, 'exportable' => false, 'printable' => false,
//            ],
//            [
//                    'data' => 'vendor_name',
//                    'title' => "Vendor Name",
//                    'searchable' => false, 'orderable' => false, 'exportable' => false, 'printable' => false,
//
//            ],
//            [
//                'data' => 'updated_at',
//                'title' => trans('lang.category_updated_at'),
//                'searchable' => false,
//            ]
//        ];
//
//        $hasCustomField = in_array(subCategory::class, setting('custom_field_models', []));
//        if ($hasCustomField) {
//            $customFieldsCollection = CustomField::where('custom_field_model', subCategory::class)->where('in_table', '=', true)->get();
//            foreach ($customFieldsCollection as $key => $field) {
//                array_splice($columns, $field->order - 1, 0, [[
//                    'data' => 'custom_fields.' . $field->name . '.view',
//                    'title' => trans('lang.category_' . $field->name),
//                    'orderable' => false,
//                    'searchable' => false,
//                ]]);
//            }
//        }
//        return $columns;
//    }
    protected function getColumns()
    {
        // TODO custom element generator
        $columns = [

            [
                'data' => 'name',
                'title' => trans('lang.user_name'),

            ],
            [
                'data' => 'email',
                'title' => trans('lang.user_email'),

            ],

            [
                'data' => 'status_type',
                'title' => 'Status',

            ],

            [
                'data' => 'updated_at',
                'title' => trans('lang.user_updated_at'),
                'searchable' => false,
            ]
        ];

        // TODO custom element generator
        $hasCustomField = in_array(User::class, setting('custom_field_models',[]));
        if ($hasCustomField) {
            $customFieldsCollection = CustomField::where('custom_field_model', User::class)->where('in_table', '=', true)->get();
            foreach ($customFieldsCollection as $key => $field) {
                array_splice($columns, $field->order - 1, 0, [[
                    'data' => 'custom_fields.' . $field->name . '.view',
                    'title' => trans('lang.user_' . $field->name),
                    'orderable' => false,
                    'searchable' => false,
                ]]);
            }
        }
        return $columns;
    }

    /**
     * Get query source of dataTable.
     *
     * @param \App\Models\User $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query(User $model)
    {
              //return dd(request('id'));
        return $model->newQuery()->whereHas('subcategories',function($query){
            $query->where('subcategory_id',request('id'));
        });
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->addAction(['title'=>trans('lang.actions'),'width' => '80px', 'printable' => false, 'responsivePriority' => '100'])
            ->parameters(array_merge(
                config('datatables-buttons.parameters'), [
                    'language' => json_decode(
                        file_get_contents(base_path('resources/lang/' . app()->getLocale() . '/datatable.json')
                        ), true)
                ]
            ));
    }

    /**
     * Export PDF using DOMPDF
     * @return mixed
     */
    public function pdf()
    {
        $data = $this->getDataForPrint();
        $pdf = PDF::loadView($this->printPreview, compact('data'));
        return $pdf->download($this->filename() . '.pdf');
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'categoriesdatatable_' . time();
    }
}